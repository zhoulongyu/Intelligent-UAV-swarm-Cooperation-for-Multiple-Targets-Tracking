import numpy as np
from multiagent.core import World, Agent, Landmark
from multiagent.scenario import BaseScenario
import pandas as pd

class Scenario(BaseScenario):
    def make_world(self):
        world = World()
        # set any world properties first
        # world.dim_c = 3        # TODO(Weiz): dim_c 是指沟通的频道，Dim_c = 10 -> action.c 10维的向量
                                            # 3-> 2：代表移动动作， 1 选取节点
        world.collaborative = False  # whether agents share rewards
        world.import_y_pos = True # True的话就从path导入路径

        # add agents
        world.agents = [Agent() for _ in range(4)]
        for i, agent in enumerate(world.agents):
            agent.name = 'agent %d' % i
            agent.collide = False
            agent.silent = True
        # add landmarks
        world.landmarks = [Landmark() for _ in range(2)]
        for i, landmark in enumerate(world.landmarks):
            landmark.name = 'landmark %d' % i
            landmark.collide = False
            landmark.movable = False
        # make initial conditions
        self.reset_world(world)
        return world

    def reset_world(self, world):
        # assign goals to agents
        for agent in world.agents:
            # agent.goal = np.random.choice(world.landmarks)
            agent.goal = world.landmarks[0] if world.agents.index(agent)<2 else world.landmarks[1]
            agent.action.t = world.landmarks.index(agent.goal)
        # random properties for agents
        for i, agent in enumerate(world.agents):
            agent.color = np.array([0.25, 0.25, 0.25])
            # random properties for landmarks
        for i, landmark in enumerate(world.landmarks):
            landmark.color = np.array([0.25, 1, np.random.random()])

        # set random initial states
        for agent in world.agents:
            agent.state.p_pos = np.random.uniform(-1, +1, world.dim_p)
            agent.state.p_vel = np.zeros(world.dim_p)
            agent.state.c = np.zeros(world.dim_c)

        if world.import_y_pos:
            self.time = 0
            path = r"C:\Users\57225\PycharmProjects\zly\target_trajectory.xlsx"
            y_trace = pd.read_excel(path, usecols=[0, 1, 2, 3])
            from sklearn.preprocessing import MinMaxScaler
            scaler = MinMaxScaler((0, 3))  # 范围归一化到0-10之间
            y_trace = scaler.fit_transform(y_trace)
            for i, landmark in enumerate(world.landmarks):
                landmark.trace = y_trace[:, i*2:(i+1)*2] # values 转成ndarray

        for i, landmark in enumerate(world.landmarks):
            if world.import_y_pos:
                landmark.state.p_pos = landmark.trace[0]
            else:
                landmark.state.p_pos = np.random.uniform(-1, +1, world.dim_p)
            landmark.state.p_vel = np.zeros(world.dim_p)

    def reward(self, agent, world):
        if agent.goal is None:
            return 0.0
        dist2 = np.sum(np.square(agent.goal.state.p_pos - agent.state.p_pos))
        return -dist2

    def observation(self, agent, world):
        # goal color
        # goal_color = [np.zeros(world.dim_color), np.zeros(world.dim_color)]
        # if agent.goal_b is not None:
        #     goal_color[1] = agent.goal_b.color
        # goal ID one-hot form
        goal_ob = np.zeros(len(world.landmarks), dtype=int)
        goal_ob[agent.action.t] = 1

        # get positions of all entities in this agent's reference frame
        entity_pos = []
        for entity in world.landmarks:
            entity_pos.append(entity.state.p_pos - agent.state.p_pos)

        # communication of all other agents
        # comm = []
        # for other in world.agents:
        #     if other is agent: continue
        #     comm.append(other.state.c) # 其他节点的动作
        return np.concatenate([agent.state.p_vel] + entity_pos + [goal_ob])
